package com.dbs.service;

import java.util.List;

import com.dbs.beans.message;
import com.dbs.beans.receiver;

public interface IReceiverService {
	
public receiver findById(String bic);
	
	public List<receiver> findAll();

}
