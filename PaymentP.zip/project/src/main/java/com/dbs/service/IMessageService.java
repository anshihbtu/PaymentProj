package com.dbs.service;

import java.util.List;

import com.dbs.beans.message;



public interface IMessageService {

	public message findById(String code);
	
	public List<message> findAll();
	

}
