package com.dbs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.beans.message;
import com.dbs.beans.receiver;
import com.dbs.dao.MessageRepo;
import com.dbs.dao.ReceiverRepo;

@Service
public class ReceiverService implements IReceiverService{

	@Autowired
	ReceiverRepo receiverRepo;
	
	@Override
	public receiver findById(String bic) {
		return receiverRepo.findById(bic).get();
	}
	@Override
	public List<receiver> findAll(){
		return receiverRepo.findAll();

}
}