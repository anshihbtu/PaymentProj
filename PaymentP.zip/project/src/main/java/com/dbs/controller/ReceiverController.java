package com.dbs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.beans.receiver;

import com.dbs.service.IReceiverService;

@RestController
public class ReceiverController {
	
	
	@Autowired
	IReceiverService receiverService;
	
	
	
	
	@GetMapping(value="rec")
	public ResponseEntity<List<receiver>> getCustomer() {
		
		List<receiver> rev = receiverService.findAll();
		return new ResponseEntity<List<receiver>>(rev, HttpStatus.OK);
	}
	
	
		@GetMapping(value="receiver/{id}")
		public ResponseEntity<receiver> getEmployee(@PathVariable("id") String bic) {
		receiver  re= receiverService.findById(bic);
			return new ResponseEntity<>(re, HttpStatus.OK);
		}
		

}
