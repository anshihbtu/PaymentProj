package com.dbs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.beans.customer;
import com.dbs.beans.message;
import com.dbs.service.ICustomerService;
import com.dbs.service.IMessageService;

@RestController
public class MessageController {
	
	@Autowired
	IMessageService messageService;
	
	
	
	
	@GetMapping(value="mssg")
	public ResponseEntity<List<message>> getMessage() {
		
		List<message> msssg = messageService.findAll();
		return new ResponseEntity<List<message>>(msssg, HttpStatus.OK);
	}
	
	
		@GetMapping(value="message/{id}")
		public ResponseEntity<message> getEmployee(@PathVariable("id") String code) {
		message msgg = messageService.findById(code);
		return new ResponseEntity<>(msgg, HttpStatus.OK);
		}
		

}
