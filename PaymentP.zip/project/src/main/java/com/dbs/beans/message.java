package com.dbs.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "message")
public class message {
	
	@Id
	@Column(name="code")
	String code;
	@Column(name="instruc")
	String instruc;
	public synchronized String getCode() {
		return code;
	}
	public synchronized void setCode(String code) {
		this.code = code;
	}
	public synchronized String getInstruc() {
		return instruc;
	}
	public synchronized void setInstruc(String instruc) {
		this.instruc = instruc;
	}
	public message(String code, String instruc) {
		super();
		this.code = code;
		this.instruc = instruc;
	}
	public message() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "message [code=" + code + ", instruc=" + instruc + "]";
	}

}
