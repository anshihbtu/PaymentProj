package com.dbs.beans;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="customer")
// @Table (name = "customer_data")
public class customer {
	

	
	
	@Id
	@Column(name="customerid")
	String customerId;
	@Column(name="name")
	String name;
	@Column(name="balance")
	int balance ;
	@Column(name="overdraft")
	String overdraft;

	public synchronized String getCustomerId() {
		return customerId;
	}

	public synchronized void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public synchronized String getName() {
		return name;
	}

	public synchronized void setName(String name) {
		this.name = name;
	}

	public synchronized int getBalance() {
		return balance;
	}

	public synchronized void setBalance(int balance) {
		this.balance = balance;
	}

	public synchronized String getOverdraft() {
		return overdraft;
	}

	public synchronized void setOverdraft(String overdraft) {
		this.overdraft = overdraft;
	}

	@Override
	public String toString() {
		return "customer [customerId=" + customerId + ", name=" + name + ", balance=" + balance + ", overdraft="
				+ overdraft + "]";
	}

	public customer(String customerId, String name, int balance, String overdraft) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.balance = balance;
		this.overdraft = overdraft;
	}

	public customer() {
		super();
		// TODO Auto-generated constructor stub
	}

}