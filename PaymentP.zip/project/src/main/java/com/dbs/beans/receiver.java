package com.dbs.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name= "receiver")
public class receiver {

	
	@Id
	@Column(name="bic")
	String bic;
	@Column(name="bankname")
	String name;
	public synchronized String getBic() {
		return bic;
	}
	public synchronized void setBic(String bic) {
		this.bic = bic;
	}
	public synchronized String getName() {
		return name;
	}
	public synchronized void setName(String name) {
		this.name = name;
	}
	public receiver(String bic, String name) {
		super();
		this.bic = bic;
		this.name = name;
	}
	public receiver() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "receiver [bic=" + bic + ", name=" + name + "]";
	}
	
	
	
}
