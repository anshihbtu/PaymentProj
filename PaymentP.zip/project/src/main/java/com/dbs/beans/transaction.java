package com.dbs.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table (name= "transaction_data")
public class transaction {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="transactionid")
	int transactionId;
	@Column(name="receiver_name")
	String receiver_name;
	@Column(name="tbic")
	String tbic;
	@Column(name="ttype")
	String ttype;
	@Column(name="sender_acc_no")
	String sender_acc_no;
	@Column(name="mcode")
	String mcode;
	@Column(name="pno")
	String pno;
	@Column(name="tf")
	int tf;
	@Column(name="cb")
	int cb;
	@Column(name="tamt")
	int tamt;
	@Column(name="date")
    String date;
	public synchronized int getTransactionId() {
		return transactionId;
	}
	public synchronized void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public synchronized String getReceiver_name() {
		return receiver_name;
	}
	public synchronized void setReceiver_name(String receiver_name) {
		this.receiver_name = receiver_name;
	}
	public synchronized String getTbic() {
		return tbic;
	}
	public synchronized void setTbic(String tbic) {
		this.tbic = tbic;
	}
	public synchronized String getTtype() {
		return ttype;
	}
	public synchronized void setTtype(String ttype) {
		this.ttype = ttype;
	}
	public synchronized String getSender_acc_no() {
		return sender_acc_no;
	}
	public synchronized void setSender_acc_no(String sender_acc_no) {
		this.sender_acc_no = sender_acc_no;
	}
	public synchronized String getMcode() {
		return mcode;
	}
	public synchronized void setMcode(String mcode) {
		this.mcode = mcode;
	}
	public synchronized String getPno() {
		return pno;
	}
	public synchronized void setPno(String pno) {
		this.pno = pno;
	}
	public synchronized int getTf() {
		return tf;
	}
	public synchronized void setTf(int tf) {
		this.tf = tf;
	}
	public synchronized int getCb() {
		return cb;
	}
	public synchronized void setCb(int cb) {
		this.cb = cb;
	}
	public synchronized int getTamt() {
		return tamt;
	}
	public synchronized void setTamt(int tamt) {
		this.tamt = tamt;
	}
	public synchronized String getDate() {
		return date;
	}
	public synchronized void setDate(String date) {
		this.date = date;
	}
	public transaction(int transactionId, String receiver_name, String tbic, String ttype, String sender_acc_no,
			String mcode, String pno, int tf, int cb, int tamt, String date) {
		super();
		this.transactionId = transactionId;
		this.receiver_name = receiver_name;
		this.tbic = tbic;
		this.ttype = ttype;
		this.sender_acc_no = sender_acc_no;
		this.mcode = mcode;
		this.pno = pno;
		this.tf = tf;
		this.cb = cb;
		this.tamt = tamt;
		this.date = date;
	}
	public transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "transaction [transactionId=" + transactionId + ", receiver_name=" + receiver_name + ", tbic=" + tbic
				+ ", ttype=" + ttype + ", sender_acc_no=" + sender_acc_no + ", mcode=" + mcode + ", pno=" + pno
				+ ", tf=" + tf + ", cb=" + cb + ", tamt=" + tamt + ", date=" + date + "]";
	}
}